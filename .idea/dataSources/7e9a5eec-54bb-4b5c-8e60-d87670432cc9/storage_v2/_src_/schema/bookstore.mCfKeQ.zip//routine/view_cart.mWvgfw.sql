create
    definer = root@localhost procedure view_cart(IN cart_idIn int)
BEGIN
	SELECT *
    FROM Cart_Items
    WHERE cart_id = cart_idIn;
END;

