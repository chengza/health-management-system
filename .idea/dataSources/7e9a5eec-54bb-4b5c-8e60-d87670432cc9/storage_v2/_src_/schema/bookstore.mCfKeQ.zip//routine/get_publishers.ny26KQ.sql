create
    definer = root@localhost procedure get_publishers()
BEGIN
    SELECT publisher_id, name
    FROM Publisher;
END;

