create
    definer = root@localhost procedure cart_empty(IN cart_idIn int)
BEGIN
    DELETE FROM Cart_Items
    WHERE cart_id = cart_idIn;
END;

