create
    definer = root@localhost procedure login_manager_by_email(IN emailIn varchar(45), IN passwordIn char(64),
                                                              OUT user_idOUT int, OUT cart_idOUT int)
BEGIN
	DECLARE realPassword CHAR(64);
    
    IF (SELECT EXISTS(
			SELECT user_id, password
			FROM Users u
			WHERE email = emailIn
	)) THEN
		SELECT user_id, password
        INTO user_idOUT, realPassword
		FROM Users u
		WHERE email = emailIn;
        IF passwordIn <> realPassword THEN
			SET user_idOUT = 0;			
			SIGNAL SQLSTATE '45000'
			SET MESSAGE_TEXT = 'Invalid username or password';
		END IF;
        
        CALL is_manager(user_idOUT);
        
        CALL init_cart(user_idOUT, cart_idOUT);
    END IF;
END;

