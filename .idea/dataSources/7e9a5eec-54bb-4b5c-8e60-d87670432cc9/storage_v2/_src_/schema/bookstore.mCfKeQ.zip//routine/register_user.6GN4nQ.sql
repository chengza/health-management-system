create
    definer = root@localhost procedure register_user(IN usernameIn varchar(45), IN passwordIn char(64),
                                                     IN last_nameIn varchar(45), IN first_nameIn varchar(45),
                                                     IN emailIn varchar(45), IN phoneIn varchar(13),
                                                     IN shipping_addressIn varchar(50), OUT user_idOUT int,
                                                     OUT cart_idOUT int)
BEGIN
	INSERT INTO Users (username, password, last_name, first_name, email, phone, shipping_address)
    VALUES (usernameIn, passwordIn, last_nameIn, first_nameIn, emailIn, phoneIn, shipping_addressIn);
    
    SET user_idOUT = (SELECT LAST_INSERT_ID());
    
    CALL init_cart(user_idOUT, cart_idOUT);
END;

