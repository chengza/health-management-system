create
    definer = root@localhost procedure promote_user_by_username(IN usernameIn varchar(45))
BEGIN
	DECLARE idIn INT;
    SET idIn = (SELECT user_id FROM Users WHERE username = usernameIn);
    
	INSERT INTO Managers (id)
    VALUES (idIn);
END;

