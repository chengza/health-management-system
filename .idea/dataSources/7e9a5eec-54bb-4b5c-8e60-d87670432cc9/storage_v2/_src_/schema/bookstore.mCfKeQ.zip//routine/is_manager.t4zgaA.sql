create
    definer = root@localhost procedure is_manager(IN idIn int)
BEGIN
	IF (SELECT NOT EXISTS(SELECT * FROM Managers WHERE id = idIn)) THEN
			SET idIn = 0;
			SIGNAL SQLSTATE '45000'
			SET MESSAGE_TEXT = 'User is not a registered manager';
        END IF;
END;

