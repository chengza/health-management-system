create
    definer = root@localhost procedure add_user_credit(IN user_idIn int, IN credit_numberIn varchar(19), IN expiryIn date)
BEGIN
    INSERT INTO Visa VALUES (user_idIn, credit_numberIn, expiryIn);
END;

