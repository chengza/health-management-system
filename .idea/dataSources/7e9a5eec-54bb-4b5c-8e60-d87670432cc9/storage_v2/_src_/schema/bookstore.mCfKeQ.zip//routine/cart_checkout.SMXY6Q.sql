create
    definer = root@localhost procedure cart_checkout(IN cart_idIn int, IN user_idIn int)
BEGIN
    DECLARE finished INT DEFAULT 0;
    DECLARE ISBNIt VARCHAR(25);
    DECLARE quantityIt INT UNSIGNED;
    DECLARE priceIt DECIMAL UNSIGNED;
    
    DECLARE cart_cursor CURSOR
    FOR	SELECT ISBN, quantity, price
		FROM Cart_Items
        WHERE cart_id = cart_idIn;


    DECLARE CONTINUE HANDLER
	FOR NOT FOUND SET finished = 1;
    
    OPEN cart_cursor;
    
    get_item : LOOP
		FETCH cart_cursor INTO ISBNIT, quantityIt, priceIt;
        IF finished = 1 THEN
			LEAVE get_item;
		END IF;


	-- update quantity of books
        UPDATE Books
        SET quantity = quantity - quantityIt
        WHERE ISBN = ISBNIt;
        
	-- update sales
        INSERT INTO Sales (user_id, ISBN, Timestamp, quantity, price)
        VALUES (user_idIn, ISBNIt, NOW(), quantityIt, priceIt);

	END LOOP get_item;
    
    CLOSE cart_cursor;
    
    CALL cart_empty(cart_idIn);
END;

