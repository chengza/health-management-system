create
    definer = root@localhost procedure get_book(IN ISBNIn varchar(25))
BEGIN
    SELECT *
    FROM Books
    WHERE ISBN = ISBNIn;
END;

