create
    definer = root@localhost procedure promote_user_by_email(IN emailIn varchar(45))
BEGIN
	DECLARE idIn INT;
    SET idIn = (SELECT user_id FROM Users WHERE email = emailIn);
    
	INSERT INTO Managers (id)
    VALUES (idIn);
END;

