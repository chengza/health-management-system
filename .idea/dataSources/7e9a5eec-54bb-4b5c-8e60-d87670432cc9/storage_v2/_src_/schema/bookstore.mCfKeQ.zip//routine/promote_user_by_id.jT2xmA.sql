create
    definer = root@localhost procedure promote_user_by_id(IN idIn int)
BEGIN
	INSERT INTO Managers (id)
    VALUES (idIn);
END;

