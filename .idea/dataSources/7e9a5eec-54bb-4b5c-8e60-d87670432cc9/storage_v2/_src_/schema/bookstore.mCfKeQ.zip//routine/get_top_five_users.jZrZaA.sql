create
    definer = root@localhost procedure get_top_five_users()
BEGIN
    SELECT username, first_name, last_name, SUM(Sales.price * Sales.quantity) as Total
    FROM Sales JOIN Users U on Sales.user_id = U.user_id
    WHERE Sales.Timestamp >= LAST_DAY(NOW()) + INTERVAL 1 DAY - INTERVAL 3 MONTH
    AND Sales.Timestamp < LAST_DAY(NOW()) + INTERVAL 1 DAY - INTERVAL 1 MONTH
    GROUP BY Sales.user_id ORDER BY Total DESC LIMIT 5;
END;

