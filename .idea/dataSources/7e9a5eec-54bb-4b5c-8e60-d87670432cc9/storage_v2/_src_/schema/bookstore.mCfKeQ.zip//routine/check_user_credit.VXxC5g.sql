create
    definer = root@localhost procedure check_user_credit(IN user_idIn int)
BEGIN
    SELECT *
    FROM Visa
    WHERE user_id = user_idIn;
END;

