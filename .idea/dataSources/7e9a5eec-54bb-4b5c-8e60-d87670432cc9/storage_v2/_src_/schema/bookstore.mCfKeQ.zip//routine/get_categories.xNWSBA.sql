create
    definer = root@localhost procedure get_categories()
BEGIN
    SELECT category_id, category_name
    FROM Category;
END;

