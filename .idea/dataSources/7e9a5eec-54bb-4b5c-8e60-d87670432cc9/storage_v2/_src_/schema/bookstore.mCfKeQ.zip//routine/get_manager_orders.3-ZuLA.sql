create
    definer = root@localhost procedure get_manager_orders()
BEGIN
    SELECT *
    FROM Mng_Order;
END;

