create
    definer = root@localhost procedure get_books_by_category(IN categoryIN int)
BEGIN
    SELECT *
    FROM Books
    WHERE category_id = categoryIN;
END;

