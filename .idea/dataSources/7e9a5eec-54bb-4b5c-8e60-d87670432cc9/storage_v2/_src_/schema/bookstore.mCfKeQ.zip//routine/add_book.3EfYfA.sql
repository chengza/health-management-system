create
    definer = root@localhost procedure add_book(IN ISBNIn varchar(25), IN titleIn varchar(60), IN publisher_idIn int,
                                                IN publication_yearIn date, IN priceIn decimal, IN quantityIn int,
                                                IN minimum_thresholdIn int, IN category_idIn int)
BEGIN
	INSERT INTO Books (ISBN, title, publisher_id, publication_year, price, quantity, minimum_threshold, category_id)
    VALUES (ISBNIn, titleIn, publisher_idIn, publication_yearIn, priceIn, quantityIn, minimum_thresholdIn, category_idIn);
END;

