create
    definer = root@localhost procedure update_user_info(IN user_idiN int, IN usernameIn varchar(45),
                                                        IN passwordIn char(64), IN last_nameIn varchar(45),
                                                        IN first_nameIn varchar(45), IN emailIn varchar(45),
                                                        IN phoneIn varchar(13), IN shipping_addressIn varchar(50))
BEGIN
	UPDATE Users
    SET
		username = usernameIn,
        password = passwordIn,
        last_name = last_nameIn,
        first_name = first_nameIn,
        email = emailIn, 
        phone = phoneIn, 
        shipping_address = shipping_addressIn
	WHERE user_id = user_idIn;
END;

