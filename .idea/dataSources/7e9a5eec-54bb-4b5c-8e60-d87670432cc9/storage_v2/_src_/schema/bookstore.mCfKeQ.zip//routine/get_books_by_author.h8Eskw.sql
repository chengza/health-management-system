create
    definer = root@localhost procedure get_books_by_author(IN nameIn varchar(50))
BEGIN
    SELECT Books.*
    FROM Books JOIN Book_Authors BA on Books.ISBN = BA.ISBN
    WHERE author_name like nameIn;
END;

