create
    definer = root@localhost procedure get_books_by_publisher(IN nameIn varchar(50))
BEGIN
    SELECT Books.*
    FROM Books JOIN Publisher P on Books.publisher_id = P.publisher_id
    WHERE name like nameIn;
END;

