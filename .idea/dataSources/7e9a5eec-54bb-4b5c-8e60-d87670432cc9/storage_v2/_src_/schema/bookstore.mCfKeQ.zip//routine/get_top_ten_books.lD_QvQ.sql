create
    definer = root@localhost procedure get_top_ten_books()
BEGIN
    SELECT Sales.ISBN, B.title, SUM(Sales.price * Sales.quantity) as Total
    FROM Sales JOIN Books B on Sales.ISBN = B.ISBN
	WHERE Sales.Timestamp >= LAST_DAY(NOW()) + INTERVAL 1 DAY - INTERVAL 3 MONTH
    AND Sales.Timestamp < LAST_DAY(NOW()) + INTERVAL 1 DAY - INTERVAL 1 MONTH
    GROUP BY Sales.ISBN ORDER BY Total DESC LIMIT 10;
END;

