create
    definer = root@localhost procedure init_cart(IN user_idIn int, OUT cart_idOUT int)
BEGIN
	INSERT INTO Carts (user_id)
    VALUES (user_idIn);
    
    SET cart_idOUT = LAST_INSERT_ID();
END;

