create
    definer = root@localhost procedure top_cart_checkout(IN cart_idIn int, IN user_idIn int)
BEGIN
 DECLARE EXIT HANDLER FOR SQLEXCEPTION
    proc_exit:BEGIN
        ROLLBACK;
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Custom error';
    END;
    START TRANSACTION;
	CALL cart_checkout(cart_idIn, user_idIn);
	COMMIT;
END;

