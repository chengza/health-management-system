create
    definer = root@localhost procedure cart_include_book(IN cart_idIn int, IN ISBNIn varchar(25), IN quantityIn int)
BEGIN
	IF (SELECT EXISTS(SELECT * FROM Cart_Items WHERE cart_id = cart_idIn AND ISBN = ISBNIn)) THEN
		UPDATE Cart_Items
        SET quantity = quantityIn
        WHERE  cart_id = cart_idIn AND ISBN = ISBNIn;
	ELSE
		INSERT INTO Cart_Items (cart_id, ISBN, quantity, price)
        VALUES (cart_idIn, ISBNIn, quantityIn, (SELECT price FROM Books WHERE ISBN = ISBNIn));
    END IF;
END;

