create
    definer = root@localhost procedure modify_book(IN oldISBN varchar(25), IN ISBNIn varchar(25),
                                                   IN titleIn varchar(60), IN publisher_idIn int,
                                                   IN publication_yearIn date, IN priceIn decimal, IN quantityIn int,
                                                   IN minimum_thresholdIn int, IN category_idIn int)
BEGIN
	IF oldISBN = ISBNIn THEN
		UPDATE Books
		SET
			title = titleIn,
			publisher_id = publisher_idIn,
			publication_year = publication_yearIn,
			price = priceIn,
			quantity = quantityIn,
			minimum_threshold = minimum_thresholdIn,
			category_id = category_idIn
		WHERE ISBN = oldISBN;
	ELSE 
		UPDATE Books
		SET
			ISBN = ISBNIn,
			title = titleIn,
			publisher_id = publisher_idIn,
			publication_year = publication_yearIn,
			price = priceIn,
			quantity = quantityIn,
			minimum_threshold = minimum_thresholdIn,
			category_id = category_idIn
		WHERE ISBN = oldISBN;
	END IF;
END;

