create
    definer = root@localhost procedure get_sales_month()
BEGIN
    SELECT Sales.ISBN, B.title, SUM(Sales.price * Sales.quantity) as Total
    FROM Sales JOIN Books B on Sales.ISBN = B.ISBN
    WHERE MONTH(Sales.Timestamp) = MONTH(DATE_SUB(CURRENT_DATE ,INTERVAL 1 MONTH))
    GROUP BY Sales.ISBN ORDER BY Total DESC;
END;

