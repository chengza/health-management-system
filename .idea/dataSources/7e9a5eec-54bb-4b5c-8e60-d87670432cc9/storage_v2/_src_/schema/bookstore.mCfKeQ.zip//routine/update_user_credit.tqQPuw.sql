create
    definer = root@localhost procedure update_user_credit(IN user_idIn int, IN credit_numberIn varchar(19), IN expiryIn date)
BEGIN
    UPDATE Visa SET credit_number = credit_numberIn, expiry = expiryIn WHERE user_id = user_idIn;
END;

