create
    definer = root@localhost procedure order_books_from_publisher(IN quantityIn int, IN publisher_idIn int,
                                                                  IN ISBNIn varchar(25), OUT order_id int)
BEGIN
	INSERT INTO Mng_Order (quantity, publisher_id, ISBN)
    VALUES (quantityIn, publisher_idIn, ISBNIn);
    
    SET order_id = (SELECT LAST_INSERT_ID());
END;

