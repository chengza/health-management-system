create
    definer = root@localhost procedure cart_remove(IN cart_idIn int)
BEGIN
    DELETE FROM Carts
    WHERE cart_id = cart_idIn;
END;

