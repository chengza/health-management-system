create
    definer = root@localhost procedure cart_exclude_book(IN cart_idIn int, IN ISBNIn varchar(25))
BEGIN
	DELETE FROM Cart_Items
    WHERE cart_id = cart_idIn AND ISBN = ISBNIn;
END;

