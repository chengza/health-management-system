create
    definer = root@localhost procedure get_users_by_username(IN usernameIn varchar(45))
BEGIN
    SELECT user_id, username, first_name, last_name
    FROM Users
    WHERE username LIKE usernameIn AND user_id NOT IN (SELECT id FROM Managers);
END;

