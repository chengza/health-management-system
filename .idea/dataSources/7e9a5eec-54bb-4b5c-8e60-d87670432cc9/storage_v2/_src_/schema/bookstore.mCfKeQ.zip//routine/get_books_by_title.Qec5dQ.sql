create
    definer = root@localhost procedure get_books_by_title(IN titleIn varchar(60))
BEGIN
    SELECT *
    FROM Books
    WHERE title like titleIn;
END;

